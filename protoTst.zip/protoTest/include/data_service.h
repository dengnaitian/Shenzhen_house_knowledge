#ifndef __DATA_SERVICE_H__
#define __DATA_SERVICE_H__

#include <string>
#include "private_data_proto.pb.h"
#include <vector>

namespace data_service{
	void printHolleWorld();
	void addTestData(privateData::Student &student1);
	void dataToPrivateData(const std::string serializedStr, std::vector<int> &privateDataArray);
}

#endif
