#include "data_service.h"
#include <iostream>
#include <string>
namespace data_service{
        void printHolleWorld(){
                privateData::Student student1;
                student1.set_id(1001);
                auto phoneNumber = student1.add_phonenumber();
                phoneNumber->set_name("deng-nai-tian");
                phoneNumber->set_phone(10086);
                std::string serializedStr;
                student1.SerializeToString(&serializedStr);
                std::cout<<"serialization result:"<<serializedStr<<std::endl; //序列化后的字符串内容是二进制内容，非可打印字符，预计输出乱码
                std::cout<<std::endl<<"debugString:"<<student1.DebugString();
                /*----------------上面是序列化，下面是反序列化-----------------------*/
                privateData::Student deserializedStudent;
                if(!deserializedStudent.ParseFromString(serializedStr)){
                std::cerr << "Failed to parse student." << std::endl;
                    return;
                }
                //打印解析后的student消息对象
                std::cout<<"deserializedStudent debugString:"<<deserializedStudent.DebugString();
                std::cout<<std::endl<<"Student ID: " << deserializedStudent.id() << std::endl;
                const auto& phone = deserializedStudent.phonenumber(0);
                std::cout<<"phone name is "<<phone.name()<<" number is "<<phone.phone()<<std::endl;

                std::cout << "hello word" << std::endl;
        }
}
