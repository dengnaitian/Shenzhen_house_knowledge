#include "data_service.h"
#include <iostream>
#include <string>
namespace data_service{
        void printHolleWorld(){
                privateData::Student student1;
                // student1.set_id(1001);
                // auto phoneNumber = student1.add_phonenumber();
                // phoneNumber->set_name("deng-nai-tian");
                // phoneNumber->set_phone(10086);
                
                addTestData(student1);
                
                std::string serializedStr;
                student1.SerializeToString(&serializedStr);

                std::vector<int> privateDataArray;
                dataToPrivateData(serializedStr, privateDataArray);
		for(const auto i : privateDataArray){
			std::cout<< i ;
		}


                std::cout<<std::endl<<"serialization result:"<<serializedStr<<std::endl; //序列化后的字符串内容是二进制内容，非可打印字符，预计输出乱码
                std::cout<<std::endl<<"debugString:"<<student1.DebugString();
                /*----------------上面是序列化，下面是反序列化-----------------------*/
                privateData::Student deserializedStudent;
                if(!deserializedStudent.ParseFromString(serializedStr)){
                std::cerr << "Failed to parse student." << std::endl;
                    return;
                }
                //打印解析后的student消息对象
                std::cout<<"deserializedStudent debugString:"<<deserializedStudent.DebugString();
                std::cout<<std::endl<<"Student ID: " << deserializedStudent.id() << std::endl;
                const auto& phone = deserializedStudent.phonenumber(0);
                std::cout<<"phone name is "<<phone.name()<<" number is "<<phone.phone()<<std::endl;

                std::cout << "hello word" << std::endl;
        }
        // 制造数据
        void addTestData(privateData::Student &student1){
            student1.set_id(1001);
            for(int i=0;i<10;i++){
                auto phoneNumber = student1.add_phonenumber();
                phoneNumber->set_name("deng-nai-tian");
                phoneNumber->set_phone(1000+i);
            }
        }
        // 数据装箱,
        void dataToPrivateData(const std::string serializedStr, std::vector<int> &privateDataArray){
            for(int i=0; i<serializedStr.length();i++){
                privateDataArray.push_back( static_cast<int>(serializedStr[i]));
            }
        }
}

