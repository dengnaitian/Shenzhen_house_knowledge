#include "data_service.h"

int main(){
	data_service::printHolleWorld();
	return 0;
}
