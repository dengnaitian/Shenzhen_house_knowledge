#!/bin/bash
echo "build proto file"
protoc --version
pwd
protoc3.13 private_data_proto.proto --cpp_out=./
